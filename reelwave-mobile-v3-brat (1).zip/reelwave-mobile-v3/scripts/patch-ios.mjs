import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const source = path.join(root, 'native', 'ios', 'ViewController.swift');
const target = path.join(root, 'ios', 'App', 'App', 'ViewController.swift');
if (!fs.existsSync(path.dirname(target))) {
  console.error('iOS project not found. Run: npx cap add ios');
  process.exit(1);
}
fs.copyFileSync(source, target);
console.log('Installed Reelwave native iPhone MP4 exporter into ios/App/App/ViewController.swift');
