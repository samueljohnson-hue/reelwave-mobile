import UIKit
import Capacitor
import AVFoundation
import CoreVideo

final class ReelwaveExportRenderer {
    private let queue = DispatchQueue(label: "com.reelwave.export", qos: .userInitiated)
    private var cancelled = false
    private let lock = NSLock()

    func cancel() {
        lock.lock(); cancelled = true; lock.unlock()
    }

    private func isCancelled() -> Bool {
        lock.lock(); defer { lock.unlock() }
        return cancelled
    }

    func export(options: JSObject, completion: @escaping (Result<URL, Error>) -> Void) {
        lock.lock(); cancelled = false; lock.unlock()
        queue.async {
            do {
                let url = try self.makeVideo(options: options)
                DispatchQueue.main.async { completion(.success(url)) }
            } catch {
                DispatchQueue.main.async { completion(.failure(error)) }
            }
        }
    }

    private enum ExportError: LocalizedError {
        case invalidInput(String)
        case writer(String)
        case cancelled
        case audio(String)

        var errorDescription: String? {
            switch self {
            case .invalidInput(let m), .writer(let m), .audio(let m): return m
            case .cancelled: return "Export cancelled."
            }
        }
    }

    private struct TextSettings {
        let title: String
        let subtitle: String
        let position: String
        let color: UIColor
        let show: Bool
    }

    private func makeVideo(options: JSObject) throws -> URL {
        guard let imageUris = options["images"] as? [String], !imageUris.isEmpty else {
            throw ExportError.invalidInput("Add at least one image before exporting.")
        }
        guard let audioUri = options["audioUri"] as? String, let audioURL = fileURL(from: audioUri) else {
            throw ExportError.invalidInput("The selected audio file could not be opened.")
        }

        let images = imageUris.compactMap { uri -> UIImage? in
            guard let u = fileURL(from: uri) else { return nil }
            return UIImage(contentsOfFile: u.path)
        }
        guard images.count == imageUris.count else {
            throw ExportError.invalidInput("One or more selected images could not be opened.")
        }

        let duration = max(0.5, options["duration"] as? Double ?? 0)
        let trimStart = max(0, options["trimStart"] as? Double ?? 0)
        let timingMode = options["timingMode"] as? String ?? "auto"
        let bpm = options["bpm"] as? Double
        let beatsPerSlide = max(1, options["beatsPerSlide"] as? Int ?? 2)
        let transition = options["transition"] as? String ?? "kenburns"
        let textObject = options["text"] as? JSObject ?? [:]
        let text = TextSettings(
            title: textObject["title"] as? String ?? "",
            subtitle: textObject["subtitle"] as? String ?? "",
            position: textObject["position"] as? String ?? "bottom",
            color: UIColor(hex: textObject["color"] as? String ?? "#f4efe9"),
            show: textObject["show"] as? Bool ?? true
        )

        let width = 720
        let height = 1280
        let fps: Int32 = 30
        let silentURL = FileManager.default.temporaryDirectory.appendingPathComponent("reelwave-silent-\(UUID().uuidString).mp4")
        let finalURL = FileManager.default.temporaryDirectory.appendingPathComponent("reelwave-\(UUID().uuidString).mp4")
        try? FileManager.default.removeItem(at: silentURL)
        try? FileManager.default.removeItem(at: finalURL)

        let writer = try AVAssetWriter(outputURL: silentURL, fileType: .mp4)
        let settings: [String: Any] = [
            AVVideoCodecKey: AVVideoCodecType.h264,
            AVVideoWidthKey: width,
            AVVideoHeightKey: height,
            AVVideoCompressionPropertiesKey: [
                AVVideoAverageBitRateKey: 6_000_000,
                AVVideoProfileLevelKey: AVVideoProfileLevelH264HighAutoLevel
            ]
        ]
        let input = AVAssetWriterInput(mediaType: .video, outputSettings: settings)
        input.expectsMediaDataInRealTime = false
        let attrs: [String: Any] = [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
            kCVPixelBufferWidthKey as String: width,
            kCVPixelBufferHeightKey as String: height
        ]
        let adaptor = AVAssetWriterInputPixelBufferAdaptor(assetWriterInput: input, sourcePixelBufferAttributes: attrs)
        guard writer.canAdd(input) else { throw ExportError.writer("iPhone could not create the video track.") }
        writer.add(input)
        guard writer.startWriting() else { throw ExportError.writer(writer.error?.localizedDescription ?? "Could not start video export.") }
        writer.startSession(atSourceTime: .zero)

        let totalFrames = max(1, Int(ceil(duration * Double(fps))))
        for frame in 0..<totalFrames {
            if isCancelled() {
                writer.cancelWriting(); try? FileManager.default.removeItem(at: silentURL)
                throw ExportError.cancelled
            }
            while !input.isReadyForMoreMediaData {
                Thread.sleep(forTimeInterval: 0.004)
                if isCancelled() { throw ExportError.cancelled }
            }
            let t = Double(frame) / Double(fps)
            autoreleasepool {
                if let pool = adaptor.pixelBufferPool,
                   let buffer = makePixelBuffer(pool: pool, width: width, height: height, images: images, t: t, totalDuration: duration, timingMode: timingMode, bpm: bpm, beatsPerSlide: beatsPerSlide, transition: transition, text: text) {
                    let time = CMTime(value: CMTimeValue(frame), timescale: fps)
                    _ = adaptor.append(buffer, withPresentationTime: time)
                }
            }
        }

        input.markAsFinished()
        let writerGroup = DispatchGroup()
        writerGroup.enter()
        writer.finishWriting { writerGroup.leave() }
        writerGroup.wait()
        guard writer.status == .completed else {
            throw ExportError.writer(writer.error?.localizedDescription ?? "Video rendering failed.")
        }
        if isCancelled() { throw ExportError.cancelled }

        try muxAudio(videoURL: silentURL, audioURL: audioURL, trimStart: trimStart, duration: duration, outputURL: finalURL)
        try? FileManager.default.removeItem(at: silentURL)
        return finalURL
    }

    private func muxAudio(videoURL: URL, audioURL: URL, trimStart: Double, duration: Double, outputURL: URL) throws {
        let composition = AVMutableComposition()
        let videoAsset = AVURLAsset(url: videoURL)
        guard let sourceVideo = videoAsset.tracks(withMediaType: .video).first,
              let compVideo = composition.addMutableTrack(withMediaType: .video, preferredTrackID: kCMPersistentTrackID_Invalid) else {
            throw ExportError.writer("Rendered video track could not be prepared.")
        }
        let videoDuration = CMTime(seconds: duration, preferredTimescale: 600)
        try compVideo.insertTimeRange(CMTimeRange(start: .zero, duration: videoDuration), of: sourceVideo, at: .zero)

        let audioAsset = AVURLAsset(url: audioURL)
        if let sourceAudio = audioAsset.tracks(withMediaType: .audio).first,
           let compAudio = composition.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid) {
            let available = max(0, audioAsset.duration.seconds - trimStart)
            let audioDuration = min(duration, available)
            if audioDuration > 0 {
                let range = CMTimeRange(start: CMTime(seconds: trimStart, preferredTimescale: 600), duration: CMTime(seconds: audioDuration, preferredTimescale: 600))
                try compAudio.insertTimeRange(range, of: sourceAudio, at: .zero)
            }
        }

        guard let exporter = AVAssetExportSession(asset: composition, presetName: AVAssetExportPresetHighestQuality) else {
            throw ExportError.audio("iPhone could not prepare the final MP4.")
        }
        exporter.outputURL = outputURL
        exporter.outputFileType = .mp4
        exporter.shouldOptimizeForNetworkUse = true
        let group = DispatchGroup()
        group.enter()
        exporter.exportAsynchronously { group.leave() }
        group.wait()
        if isCancelled() { exporter.cancelExport(); throw ExportError.cancelled }
        guard exporter.status == .completed else {
            throw ExportError.audio(exporter.error?.localizedDescription ?? "Audio could not be added to the MP4.")
        }
    }

    private func makePixelBuffer(pool: CVPixelBufferPool, width: Int, height: Int, images: [UIImage], t: Double, totalDuration: Double, timingMode: String, bpm: Double?, beatsPerSlide: Int, transition: String, text: TextSettings) -> CVPixelBuffer? {
        var buffer: CVPixelBuffer?
        guard CVPixelBufferPoolCreatePixelBuffer(nil, pool, &buffer) == kCVReturnSuccess, let pixelBuffer = buffer else { return nil }

        let frameImage = renderFrame(size: CGSize(width: width, height: height), images: images, t: t, totalDuration: totalDuration, timingMode: timingMode, bpm: bpm, beatsPerSlide: beatsPerSlide, transition: transition, text: text)
        guard let cgImage = frameImage.cgImage else { return nil }

        CVPixelBufferLockBaseAddress(pixelBuffer, [])
        defer { CVPixelBufferUnlockBaseAddress(pixelBuffer, []) }
        guard let base = CVPixelBufferGetBaseAddress(pixelBuffer) else { return nil }
        let bytesPerRow = CVPixelBufferGetBytesPerRow(pixelBuffer)
        guard let ctx = CGContext(data: base, width: width, height: height, bitsPerComponent: 8, bytesPerRow: bytesPerRow, space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGBitmapInfo.byteOrder32Little.rawValue | CGImageAlphaInfo.premultipliedFirst.rawValue) else { return nil }
        ctx.clear(CGRect(x: 0, y: 0, width: width, height: height))
        ctx.translateBy(x: 0, y: CGFloat(height))
        ctx.scaleBy(x: 1, y: -1)
        ctx.draw(cgImage, in: CGRect(x: 0, y: 0, width: width, height: height))
        return pixelBuffer
    }

    private func renderFrame(size: CGSize, images: [UIImage], t: Double, totalDuration: Double, timingMode: String, bpm: Double?, beatsPerSlide: Int, transition: String, text: TextSettings) -> UIImage {
        let renderer = UIGraphicsImageRenderer(size: size)
        return renderer.image { context in
            UIColor.black.setFill(); context.fill(CGRect(origin: .zero, size: size))
            let n = images.count
            var slideDuration: Double
            if timingMode == "beat", let bpm = bpm, bpm > 0 {
                slideDuration = Double(beatsPerSlide) * 60.0 / bpm
            } else {
                slideDuration = totalDuration / Double(max(1, n))
            }
            slideDuration = max(0.35, slideDuration)
            var idx = Int(floor(t / slideDuration))
            var local = t - Double(idx) * slideDuration
            if timingMode == "auto" && idx >= n { idx = n - 1; local = slideDuration }
            idx = ((idx % n) + n) % n
            let next = (idx + 1) % n
            let overlap = transition == "cut" ? 0 : min(0.6, slideDuration * 0.3)
            let progress = max(0.0, min(1.0, local / slideDuration))
            let zoom = transition == "kenburns" ? 1.0 + 0.14 * progress : 1.0
            let bratGreen = UIColor(red: 138.0/255.0, green: 206.0/255.0, blue: 0, alpha: 1)

            if transition == "brat1" {
                bratGreen.setFill(); context.fill(CGRect(origin: .zero, size: size))
                let pulse = CGFloat(1.0 + 0.045 * sin(progress * .pi * 2.0))
                let inset: CGFloat = 34
                context.cgContext.saveGState()
                context.cgContext.translateBy(x: size.width/2, y: size.height/2)
                context.cgContext.scaleBy(x: pulse, y: pulse)
                context.cgContext.translateBy(x: -size.width/2, y: -size.height/2)
                drawCover(images[idx], in: CGRect(x: inset, y: inset, width: size.width-inset*2, height: size.height-inset*2), zoom: 1.03)
                context.cgContext.restoreGState()
                if overlap > 0, local > slideDuration - overlap, n > 1 {
                    let p = CGFloat((local - (slideDuration - overlap)) / overlap)
                    context.cgContext.saveGState(); context.cgContext.setAlpha(p)
                    bratGreen.setFill(); context.fill(CGRect(origin: .zero, size: size))
                    drawCover(images[next], in: CGRect(x: inset, y: inset, width: size.width-inset*2, height: size.height-inset*2), zoom: 1.03)
                    context.cgContext.restoreGState()
                }
                bratGreen.withAlphaComponent(0.10).setFill(); context.fill(CGRect(origin: .zero, size: size))
            } else if transition == "brat2" {
                let jx = CGFloat(sin(local * 29.0) * 10.0)
                let jy = CGFloat(cos(local * 23.0) * 7.0)
                let rot = CGFloat(sin(local * 17.0) * 0.008)
                let punch = CGFloat(1.06 + 0.05 * sin(progress * .pi))
                context.cgContext.saveGState()
                context.cgContext.translateBy(x: size.width/2 + jx, y: size.height/2 + jy)
                context.cgContext.rotate(by: rot)
                context.cgContext.scaleBy(x: punch, y: punch)
                context.cgContext.translateBy(x: -size.width/2, y: -size.height/2)
                drawCover(images[idx], in: CGRect(origin: .zero, size: size), zoom: 1)
                context.cgContext.restoreGState()
                bratGreen.withAlphaComponent(0.12).setFill(); context.fill(CGRect(origin: .zero, size: size))
                if overlap > 0, local > slideDuration - overlap, n > 1 {
                    let p = CGFloat((local - (slideDuration - overlap)) / overlap)
                    if p < 0.18 { bratGreen.setFill(); context.fill(CGRect(origin: .zero, size: size)) }
                    context.cgContext.saveGState(); context.cgContext.setAlpha(min(1, p * 1.35))
                    context.cgContext.translateBy(x: (1-p)*42, y: 0)
                    drawCover(images[next], in: CGRect(origin: .zero, size: size), zoom: 1.08 - 0.08*p)
                    context.cgContext.restoreGState()
                }
            } else if transition == "slide", overlap > 0, local > slideDuration - overlap, n > 1 {
                let p = (local - (slideDuration - overlap)) / overlap
                drawCover(images[idx], in: CGRect(x: -CGFloat(p) * size.width, y: 0, width: size.width, height: size.height), zoom: 1)
                drawCover(images[next], in: CGRect(x: size.width - CGFloat(p) * size.width, y: 0, width: size.width, height: size.height), zoom: 1)
            } else {
                drawCover(images[idx], in: CGRect(origin: .zero, size: size), zoom: CGFloat(zoom))
                if overlap > 0, local > slideDuration - overlap, n > 1 {
                    let p = CGFloat((local - (slideDuration - overlap)) / overlap)
                    context.cgContext.saveGState(); context.cgContext.setAlpha(p)
                    drawCover(images[next], in: CGRect(origin: .zero, size: size), zoom: 1)
                    context.cgContext.restoreGState()
                }
            }
            drawText(text, size: size)
        }
    }

    private func drawCover(_ image: UIImage, in rect: CGRect, zoom: CGFloat) {
        let imageRatio = image.size.width / image.size.height
        let targetRatio = rect.width / rect.height
        var drawSize: CGSize
        if imageRatio > targetRatio {
            drawSize = CGSize(width: rect.height * imageRatio, height: rect.height)
        } else {
            drawSize = CGSize(width: rect.width, height: rect.width / imageRatio)
        }
        drawSize.width *= zoom; drawSize.height *= zoom
        let drawRect = CGRect(x: rect.midX - drawSize.width / 2, y: rect.midY - drawSize.height / 2, width: drawSize.width, height: drawSize.height)
        let path = UIBezierPath(rect: rect)
        path.addClip()
        image.draw(in: drawRect)
    }

    private func drawText(_ text: TextSettings, size: CGSize) {
        guard text.show, !text.title.isEmpty || !text.subtitle.isEmpty else { return }
        let maxWidth = size.width - 112
        let paragraph = NSMutableParagraphStyle(); paragraph.alignment = .center; paragraph.lineBreakMode = .byWordWrapping
        let titleFont = UIFont.systemFont(ofSize: 54, weight: .heavy)
        let subtitleFont = UIFont.systemFont(ofSize: 30, weight: .medium)
        let titleAttrs: [NSAttributedString.Key: Any] = [.font: titleFont, .foregroundColor: text.color, .paragraphStyle: paragraph]
        let subAttrs: [NSAttributedString.Key: Any] = [.font: subtitleFont, .foregroundColor: text.color.withAlphaComponent(0.88), .paragraphStyle: paragraph]
        let constraint = CGSize(width: maxWidth, height: .greatestFiniteMagnitude)
        let titleRect = (text.title as NSString).boundingRect(with: constraint, options: [.usesLineFragmentOrigin, .usesFontLeading], attributes: titleAttrs, context: nil)
        let subRect = (text.subtitle as NSString).boundingRect(with: constraint, options: [.usesLineFragmentOrigin, .usesFontLeading], attributes: subAttrs, context: nil)
        let gap: CGFloat = text.title.isEmpty || text.subtitle.isEmpty ? 0 : 14
        let blockH = ceil(titleRect.height) + ceil(subRect.height) + gap + 40
        let top: CGFloat
        switch text.position {
        case "top": top = 70
        case "center": top = (size.height - blockH) / 2
        default: top = size.height - blockH - 90
        }
        UIColor.black.withAlphaComponent(0.48).setFill()
        UIBezierPath(roundedRect: CGRect(x: 24, y: top - 20, width: size.width - 48, height: blockH + 40), cornerRadius: 18).fill()
        var y = top + 20
        if !text.title.isEmpty {
            (text.title as NSString).draw(with: CGRect(x: 56, y: y, width: maxWidth, height: ceil(titleRect.height) + 4), options: [.usesLineFragmentOrigin, .usesFontLeading], attributes: titleAttrs, context: nil)
            y += ceil(titleRect.height) + gap
        }
        if !text.subtitle.isEmpty {
            (text.subtitle as NSString).draw(with: CGRect(x: 56, y: y, width: maxWidth, height: ceil(subRect.height) + 4), options: [.usesLineFragmentOrigin, .usesFontLeading], attributes: subAttrs, context: nil)
        }
    }

    private func fileURL(from string: String) -> URL? {
        if let url = URL(string: string), url.isFileURL { return url }
        if string.hasPrefix("/") { return URL(fileURLWithPath: string) }
        return nil
    }
}

@objc(ReelwaveExporterPlugin)
public class ReelwaveExporterPlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "ReelwaveExporterPlugin"
    public let jsName = "ReelwaveExporter"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "export", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "cancel", returnType: CAPPluginReturnPromise)
    ]
    private let renderer = ReelwaveExportRenderer()

    @objc func export(_ call: CAPPluginCall) {
        renderer.export(options: call.options) { result in
            switch result {
            case .success(let url): call.resolve(["uri": url.absoluteString, "extension": "mp4"])
            case .failure(let error): call.reject(error.localizedDescription, nil, error)
            }
        }
    }

    @objc func cancel(_ call: CAPPluginCall) {
        renderer.cancel(); call.resolve()
    }
}

public class ViewController: CAPBridgeViewController {
    public override func capacitorDidLoad() {
        bridge?.registerPluginInstance(ReelwaveExporterPlugin())
    }
}

private extension UIColor {
    convenience init(hex: String) {
        var value = hex.trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: "#", with: "")
        if value.count == 3 { value = value.map { "\($0)\($0)" }.joined() }
        var rgb: UInt64 = 0
        Scanner(string: value).scanHexInt64(&rgb)
        self.init(red: CGFloat((rgb >> 16) & 0xff) / 255, green: CGFloat((rgb >> 8) & 0xff) / 255, blue: CGFloat(rgb & 0xff) / 255, alpha: 1)
    }
}
