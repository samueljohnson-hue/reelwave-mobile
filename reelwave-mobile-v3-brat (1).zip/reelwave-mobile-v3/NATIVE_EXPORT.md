# Reelwave native iPhone MP4 exporter

Reelwave now contains a native iOS exporter in `native/ios/ViewController.swift`.

It uses Apple AVFoundation to:
- render the selected still images at 720x1280 / 30 fps;
- reproduce Reelwave's cut, Ken Burns/crossfade, and slide transitions;
- render the title/subtitle overlay;
- trim the selected audio at the chosen start point;
- mux video + audio into an H.264/AAC `.mp4`;
- return the file URI to the web UI for preview and the native Share sheet.

## First iOS setup on a Mac

```bash
npm install
npx cap add ios
npm run patch:ios
npx cap sync ios
npx cap open ios
```

If `ios/` already exists, do not run `npx cap add ios` again. Run:

```bash
npm run patch:ios
npx cap sync ios
```

The patch script replaces the generated `ios/App/App/ViewController.swift` with Reelwave's custom bridge/controller and exporter.

## Android

Android keeps the existing MediaRecorder/canvas export path. Set it up with:

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

## Important build note

This package was prepared in a Linux build environment, so Xcode/iOS Simulator compilation cannot be executed here. The iOS source is implemented against Capacitor 8's documented local custom plugin bridge and Apple's AVFoundation APIs. Final device compilation/signing must be done in Xcode on macOS.
