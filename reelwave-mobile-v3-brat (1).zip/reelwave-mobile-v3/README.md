# Reelwave Mobile v2

This package turns the Reelwave web editor into a Capacitor 8 mobile project and includes a native iPhone MP4 export pipeline.

## Core Reelwave flow

- Pick a local audio file.
- Pick and reorder images.
- Trim the track.
- Preview a vertical 9:16 video.
- Choose automatic or beat-based slide timing.
- Use cut, Ken Burns/crossfade, or slide transitions.
- Add title/subtitle text.
- Export the result.
- Preview and share/save the finished video.

## iPhone export

On iOS the app no longer depends on `MediaRecorder` or `canvas.captureStream()` for export. Reelwave contains a native Capacitor bridge in `native/ios/ViewController.swift` that uses Apple AVFoundation to render a 720x1280, 30 fps H.264 MP4, apply the Reelwave transitions/text, trim the selected audio, and mux audio + video into the final file.

The web UI automatically uses this native exporter when running inside the iOS Capacitor app. The returned MP4 is previewed in Reelwave and sent directly to the native Share sheet when the user taps **Share / save video**.

## Android export

Android continues to use the existing `MediaRecorder` + canvas/audio capture exporter where supported, followed by Capacitor's native Filesystem and Share plugins.

## First iPhone setup on a Mac

```bash
npm install
npx cap add ios
npm run patch:ios
npx cap sync ios
npx capacitor-assets generate
npx cap open ios
```

`npm run patch:ios` installs Reelwave's custom `ViewController.swift` into the generated Xcode app. If the `ios/` project already exists, do not add it again; run `npm run patch:ios` and `npx cap sync ios` after changes.

The Apple privacy manifest template is at `ios-template/App/PrivacyInfo.xcprivacy`. Add it to the App target in Xcode when preparing the signed App Store build.

## First Android setup

```bash
npm install
npx cap add android
npx cap sync android
npx capacitor-assets generate
npx cap open android
```

## Bundle ID

The current app identifier is:

`com.samueljohnson.reelwave`

If you want a different permanent identifier, change `appId` in `capacitor.config.ts` before creating the final App Store / Play Store records.

## Build-environment note

The source package was prepared in a Linux environment. Android tooling can be built on supported desktop platforms, but Apple's iOS project must ultimately be compiled, run on a simulator/device, signed, and archived using Xcode on macOS. That final Xcode compilation cannot be performed in this environment.


## Brat presets
- Brat Style 1: acid-green framed photo treatment with rhythmic snap/zoom motion and green handoff.
- Brat Style 2: full-bleed chaotic micro-jitter/tilt, green tint/flash, and offset handoff.
- Both are implemented in the web/Android canvas preview/export path and the native iOS AVFoundation renderer.
